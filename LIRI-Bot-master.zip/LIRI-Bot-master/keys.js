exports.twitterKeys = {
  consumer_key: 'x9esgYhTFk7oXePVEDdQ2Igjx',
  consumer_secret: 'PNUKFzG1Mf2FuLSpP4ZOjS7OGVGBm9kdvcgzSiM9PDreR1zhzy',
  access_token_key: '917984062148612097-2HnZkZaa1YPOaroaODchTtI6AXSPnIb',
  access_token_secret: 'o6J9AwdWkPuUxZsuJRHNmuQdwdQTa5zOpEXQLFQgTFHbW',
};

exports.spotifyKeys = {
	client_id: '49359df6dc324aa0af4c4b5429f2d2b9',
	client_secret: '46a9c0ae16cd41c79173fb9f7416bed6'
};