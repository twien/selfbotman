rm ./log.txt
node liri.js my-tweets
node liri.js spotify-this-song 'Sorry Not Sorry'
node liri.js spotify-this-song
node liri.js movie-this 'Willy Wonka'
node liri.js movie-this
node liri.js do-what-it-says