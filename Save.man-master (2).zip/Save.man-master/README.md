# LIN3-TCR
BOT Chivas Edited V.2 Login Token / Link

Catatan : 
- Bot Ini Menggunakan 10 Akun Bot + 1 Akun admin <br>

Cara Install Via Android :
- Download Termux & Install<br>
- pkg install python2<br>
- pip2 install rsa<br>
- pip2 install requests<br>
- pip2 install thrift==0.9.3<br>
- pkg install git<br>
- pkg install nano<br>
- git clone https://github.com/andyihsan/LIN3-TCR<br>
- Selesai

Cara Membuka/Mengedit File :
- Wajib Pakai Keyboard Hacker Download di PS<br>
- cd LIN3-TCR && nano line-tcr.py<br>
- Selesai Edit Save CTRL + X Lalu Y, Dan Enter<br>
- Keluarkan Termux<br>

Cara Membuka/Mengedit File Via Internal :
- Smartphone Telah Di Root<br>
- masuk root/data/data/com.termux/file/home/LIN3-TCR/line-tcr.py<br>

Cara Menjalankan Bot :
- cd LIN3-TCR && python2 line-tcr.py<br>
- Loginkan Dengan Akun Bot Kalian Lalu Masukkan MID Admin
